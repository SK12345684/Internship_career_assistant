# CareerGuide Website
Open `index.html` in Chrome/Edge.

Features:
- Career paths for Python, Java, Digital Marketing, Finance, Accounting, Management and UI/UX
- Functional career roadmap popups
- Student Career Assistant chatbot
- Resume, Project and Internship toolkit
- Responsive design for desktop/mobile

This is a front-end prototype. The chatbot currently uses built-in demo responses; an AI API can be connected later.
